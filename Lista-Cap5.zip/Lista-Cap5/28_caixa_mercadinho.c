#include <stdio.h>

float calculaSubtotal(float preco, int quantidade);
float aplicaDesconto(float valor, int opcaoPagamento);
float calculaTroco(float total, float pago);

int main(void) {
    float preco, subtotal, total, pago, troco;
    int quantidade, opcaoPagamento;

    printf("Preco do produto: ");
    scanf("%f", &preco);
    printf("Quantidade: ");
    scanf("%d", &quantidade);
    if (preco < 0 || quantidade < 0) {
        printf("Preco e quantidade nao podem ser negativos.\n");
        return 1;
    }

    printf("Forma de pagamento (1 - a vista; 2 - outras formas): ");
    scanf("%d", &opcaoPagamento);

    subtotal = calculaSubtotal(preco, quantidade);
    total = aplicaDesconto(subtotal, opcaoPagamento);
    printf("Subtotal = R$ %.2f\n", subtotal);
    printf("Total a pagar = R$ %.2f\n", total);

    printf("Valor pago: R$ ");
    scanf("%f", &pago);
    if (pago < total) {
        printf("Valor pago insuficiente. Faltam R$ %.2f\n", total - pago);
    } else {
        troco = calculaTroco(total, pago);
        printf("Troco = R$ %.2f\n", troco);
    }
    return 0;
}

float calculaSubtotal(float preco, int quantidade) {
    return preco * quantidade;
}

float aplicaDesconto(float valor, int opcaoPagamento) {
    if (opcaoPagamento == 1) return valor * 0.90f;
    return valor;
}

float calculaTroco(float total, float pago) {
    return pago - total;
}
