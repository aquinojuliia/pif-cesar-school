| Constante  | Classificação                                                     | Tipo base em C |
| ---------- | ----------------------------------------------------------------- | -------------- |
| `\r`       | Sequência de escape                                               | `char`         |
| `2130`     | Constante inteira decimal                                         | `int`          |
| `-123`     | Constante inteira decimal                                         | `int`          |
| `33.28`    | Constante de ponto flutuante                                      | `double`       |
| `0XFA`     | Constante inteira hexadecimal                                     | `int`          |
| `0101`     | Constante inteira octal                                           | `int`          |
| `2.0e30`   | Constante de ponto flutuante em notação científica                | `double`       |
| `\xDC`     | Sequência de escape hexadecimal                                   | `char`         |
| `"\?"`     | Constante de caractere                                            | `char`         |
| `'\\'`     | Constante de caractere (barra invertida)                          | `char`         |
| `'F'`      | Constante de caractere                                            | `char`         |
| `0`        | Constante inteira decimal                                         | `int`          |
| `'\0'`     | Constante de caractere com sequência de escape                    | `char`         |
| `"F"`      | Constante string                                                  | `char`         |
| `-4567.89` | Constante de ponto flutuante                                      | `double`       |
