#include <stdio.h>

int main(void) {
    const int senhaSecreta = 2026;
    int senha, tentativas = 0;
    int acesso = 0;

    while (tentativas < 3) {
        printf("Digite a senha: ");
        scanf("%d", &senha);

        tentativas++;

        if (senha == senhaSecreta) {
            printf("Acesso Concedido!\n");
            acesso = 1;
            break;
        }

        printf("Senha incorreta.\n");
    }

    if (!acesso) {
        printf("Conta Bloqueada por Seguranca!\n");
    }

    return 0;
}
