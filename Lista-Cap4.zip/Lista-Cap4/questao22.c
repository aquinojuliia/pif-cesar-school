#include <stdio.h>
int main(void) {
    float valor, taxa; int estado;
    printf("Valor do produto: "); scanf("%f", &valor);
    printf("Estado (1-MG, 2-SP, 3-RJ, 4-MS): "); scanf("%d", &estado);
    if (valor<0) { puts("Valor invalido."); return 0; }
    switch (estado) {
        case 1: taxa=0.07; break;
        case 2: taxa=0.12; break;
        case 3: taxa=0.15; break;
        case 4: taxa=0.08; break;
        default: puts("Codigo de estado invalido."); return 0;
    }
    printf("Preco final: R$ %.2f\\n", valor*(1+taxa));
    return 0;
}
