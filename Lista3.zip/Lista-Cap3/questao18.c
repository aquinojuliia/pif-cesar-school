#include <stdio.h>

int main(void) {
    int numero, invertido = 0, digito;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &numero);

    if (numero < 0) {
        printf("Digite um numero positivo.\n");
        return 0;
    }

    if (numero == 0) {
        invertido = 0;
    }

    while (numero > 0) {
        digito = numero % 10;
        invertido = invertido * 10 + digito;
        numero /= 10;
    }

    printf("Numero invertido: %d\n", invertido);

    return 0;
}
