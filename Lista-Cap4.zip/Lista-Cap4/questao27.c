#include <stdio.h>
int main(void) {
    int horas; float valor;
    printf("Horas inteiras no estacionamento: "); scanf("%d", &horas);
    if (horas<=0) { puts("Quantidade de horas invalida."); return 0; }
    if (horas<=2) valor=horas*2.00;
    else if (horas<=4) valor=2*2.00+(horas-2)*2.50;
    else valor=2*2.00+2*2.50+(horas-4)*3.00;
    printf("Tempo total: %d hora(s)\\nValor final: R$ %.2f\\n", horas,valor);
    return 0;
}
