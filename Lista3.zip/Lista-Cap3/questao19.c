#include <stdio.h>

int main(void) {
    int N, i;
    long long int a = 1, b = 1, proximo;

    printf("Digite o numero do termo: ");
    scanf("%d", &N);

    if (N <= 0) {
        printf("N deve ser positivo.\n");
        return 0;
    }

    printf("Termos ate N:\n");

    if (N >= 1) {
        printf("1");
    }

    if (N >= 2) {
        printf(" 1");
    }

    for (i = 3; i <= N; i++) {
        proximo = a + b;
        printf(" %lld", proximo);
        a = b;
        b = proximo;
    }

    printf("\n");

    if (N == 1) {
        printf("Termo %d = 1\n", N);
    } else if (N == 2) {
        printf("Termo %d = 1\n", N);
    } else {
        printf("Termo %d = %lld\n", N, b);
    }

    return 0;
}
