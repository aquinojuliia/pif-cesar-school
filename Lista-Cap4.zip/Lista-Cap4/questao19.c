#include <stdio.h>
int main(void) {
    double a,b,c;
    printf("Digite os tres lados: "); scanf("%lf %lf %lf", &a,&b,&c);
    if (a<=0 || b<=0 || c<=0 || a>=b+c || b>=a+c || c>=a+b)
        puts("Erro: Os lados fornecidos nao formam um triangulo!");
    else if (a==b && b==c) puts("Triangulo equilatero.");
    else if (a==b || a==c || b==c) puts("Triangulo isosceles.");
    else puts("Triangulo escaleno.");
    return 0;
}
