#include <stdio.h>
#include <math.h>
int main(void) {
    double a, b, r; char op;
    printf("Operacao (+ - * / ^): "); scanf(" %c", &op);
    printf("Digite dois numeros: "); scanf("%lf %lf", &a, &b);
    switch (op) {
        case '+': r=a+b; printf("Resultado: %.2f\\n", r); break;
        case '-': r=a-b; printf("Resultado: %.2f\\n", r); break;
        case '*': r=a*b; printf("Resultado: %.2f\\n", r); break;
        case '/':
            if (b == 0) puts("Erro: divisao por zero!");
            else { r=a/b; printf("Resultado: %.2f\\n", r); }
            break;
        case '^': r=pow(a,b); printf("Resultado: %.2f\\n", r); break;
        default: puts("Operacao invalida.");
    }
    return 0;
}
/* GCC: gcc questao13.c -o questao13 -lm */
