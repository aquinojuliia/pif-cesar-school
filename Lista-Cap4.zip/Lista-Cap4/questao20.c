#include <stdio.h>
#include <math.h>
int main(void) {
    double a,b,c,delta,x1,x2;
    printf("Digite a, b e c (a diferente de zero): ");
    scanf("%lf %lf %lf", &a,&b,&c);
    if (a==0) { puts("Erro: a deve ser diferente de zero."); return 0; }
    delta=b*b-4*a*c;
    if (delta<0) puts("A equacao nao possui raizes reais.");
    else if (delta==0) {
        x1=-b/(2*a); printf("Raiz unica: %.2f\\n", x1);
    } else {
        x1=(-b+sqrt(delta))/(2*a); x2=(-b-sqrt(delta))/(2*a);
        printf("Raizes: x1 = %.2f e x2 = %.2f\\n", x1,x2);
    }
    return 0;
}
/* GCC: gcc questao20.c -o questao20 -lm */
