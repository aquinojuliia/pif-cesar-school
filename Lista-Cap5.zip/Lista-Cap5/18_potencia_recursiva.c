#include <stdio.h>

long potencia(int base, int expoente);

int main(void) {
    int base, expoente;
    printf("Digite a base e um expoente nao negativo: ");
    scanf("%d %d", &base, &expoente);
    if (expoente < 0) {
        printf("O expoente nao pode ser negativo.\n");
    } else {
        printf("Resultado = %ld\n", potencia(base, expoente));
    }
    return 0;
}

long potencia(int base, int expoente) {
    if (expoente == 0) return 1; // Caso base
    return base * potencia(base, expoente - 1); // Passo recursivo
}
