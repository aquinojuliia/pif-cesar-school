#include <stdio.h>
int main(void) {
    float km, litros, consumo;
    printf("Distancia em km: "); scanf("%f", &km);
    printf("Litros consumidos: "); scanf("%f", &litros);
    if (km < 0 || litros <= 0) { puts("Valores invalidos."); return 0; }
    consumo = km / litros;
    printf("Consumo: %.2f km/l\\n", consumo);
    if (consumo < 8.0) puts("Venda o carro!");
    else if (consumo <= 14.0) puts("Economico!");
    else puts("Super economico!");
    return 0;
}
