#include <stdio.h>
int main(void) {
    int opcao;
    puts("===== ATENDIMENTO AUTOMATICO BANCARIO =====");
    puts("1 - Consultar Saldo");
    puts("2 - Efetuar Extrato");
    puts("3 - Fazer Transferencia");
    puts("4 - Falar com Atendente");
    printf("Opcao: "); scanf("%d", &opcao);
    switch (opcao) {
        case 1: puts("Direcionando para consulta de saldo..."); break;
        case 2: puts("Direcionando para emissao de extrato..."); break;
        case 3: puts("Direcionando para transferencia..."); break;
        case 4: puts("Direcionando para um atendente..."); break;
        default: puts("Opcao invalida. Escolha de 1 a 4.");
    }
    return 0;
}
