#include <stdio.h>
int main(void) {
    int a,b,c;
    printf("Digite os tres angulos: "); scanf("%d %d %d", &a,&b,&c);
    if (a<=0 || b<=0 || c<=0 || a+b+c!=180)
        puts("Angulos invalidos: nao formam um triangulo.");
    else if (a==90 || b==90 || c==90) puts("Triangulo retangulo.");
    else if (a>90 || b>90 || c>90) puts("Triangulo obtusangulo.");
    else puts("Triangulo acutangulo.");
    return 0;
}
