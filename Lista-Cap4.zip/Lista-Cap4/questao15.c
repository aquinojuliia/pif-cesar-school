#include <stdio.h>
int main(void) {
    int idade, tempo;
    printf("Idade: "); scanf("%d", &idade);
    printf("Tempo de servico: "); scanf("%d", &tempo);
    if (idade >= 65 || tempo >= 30 || (idade >= 60 && tempo >= 25))
        puts("Pode se aposentar.");
    else puts("Ainda nao pode se aposentar.");
    return 0;
}
