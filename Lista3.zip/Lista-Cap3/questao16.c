#include <stdio.h>

int main(void) {
    const int senhaSecreta = 2026;
    int senha, tentativas;
    int acesso = 0;

    for (tentativas = 1; tentativas <= 3; tentativas++) {
        printf("Digite a senha: ");
        scanf("%d", &senha);

        if (senha == senhaSecreta) {
            printf("Acesso Concedido!\n");
            printf("Tentativas utilizadas: %d\n", tentativas);
            acesso = 1;
            break;
        } else {
            printf("Senha incorreta.\n");
        }
    }

    if (!acesso) {
        printf("Conta Bloqueada por Seguranca!\n");
    }

    return 0;
}
