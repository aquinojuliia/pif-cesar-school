#include <stdio.h>

int main(void) {
    float valor, soma = 0.0;
    int quantidade = 0;
    float media;

    printf("Digite valores positivos (valor negativo encerra):\n");

    while (1) {
        scanf("%f", &valor);

        if (valor < 0) {
            break;
        }

        soma += valor;
        quantidade++;
    }

    printf("Quantidade de valores: %d\n", quantidade);
    printf("Soma total: %.2f\n", soma);

    if (quantidade > 0) {
        media = soma / quantidade;
        printf("Media: %.2f\n", media);
    } else {
        printf("Media: nao existe, pois nenhum valor foi informado.\n");
    }

    return 0;
}
