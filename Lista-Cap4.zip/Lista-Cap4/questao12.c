#include <stdio.h>
int main(void) {
    int d;
    printf("Digite um numero de 1 a 7: "); scanf("%d", &d);
    switch (d) {
        case 1: puts("Domingo"); break;
        case 2: puts("Segunda-feira"); break;
        case 3: puts("Terca-feira"); break;
        case 4: puts("Quarta-feira"); break;
        case 5: puts("Quinta-feira"); break;
        case 6: puts("Sexta-feira"); break;
        case 7: puts("Sabado"); break;
        default: puts("Erro: Opcao Invalida!");
    }
    return 0;
}
