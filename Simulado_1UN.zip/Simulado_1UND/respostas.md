# Respostas Teóricas — Simulado 1ª Unidade

## Questão 01
**Resposta: c)** Todos os pares de nomes (`valor`/`VALOR`, `peso`/`Peso`, `taxa`/`TAXA`) representam identificadores totalmente distintos para o compilador.

## Questão 02
Os três erros são:

1. `int Main()` deve ser `int main()`.
2. O texto do `printf` deve estar entre aspas duplas.
3. `cout << endl;` é sintaxe de C++, não de C. Em C, deve-se usar `printf("\n");`.

## Questão 03
Valores finais:

- **a = 56**
- **b = 45**
- **c = 13**
- **d = 10**

## Questão 04
a) **1 (Verdadeiro)**  
b) **1 (Verdadeiro)**  
c) **1 (Verdadeiro)**  
d) **1 (Verdadeiro)**  
e) **1 (Verdadeiro)**

## Questão 05
**a)** O `while` testa a condição antes de executar o bloco, podendo executar zero vezes. O `do-while` executa o bloco primeiro e testa a condição depois, executando pelo menos uma vez.

**b)** O `for` é mais adequado quando a inicialização, a condição e a atualização do contador são conhecidas e ficam bem definidas em uma única estrutura.

**c)** `while (condicao);` é sintaticamente válido, mas normalmente representa um erro de lógica. O ponto e vírgula cria um corpo vazio para o `while`. Se a condição for verdadeira e não mudar, pode ocorrer um laço infinito.

## Questão 06
**a)** Porque a variável `soma` foi declarada dentro do bloco do `for`. Seu escopo termina ao fechar esse bloco, portanto ela não pode ser utilizada no `printf` que está fora dele.

**b)** As iterações são `i = 1, 2, 3, 4, 5, 6, 7 e 8`. O `continue` em `i = 5` pula essa iteração, e o `break` em `i = 8` encerra o laço. Assim, entram na soma os valores `1, 2, 3, 4, 6 e 7`.

**c)** A variável `soma` deve ser declarada antes do `for`. O resultado será:

**Soma final = 115**
