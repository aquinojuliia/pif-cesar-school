# Lista de Exercícios – Capítulo 3: Laços de Repetição

## Questão 01 – Diferenças Fundamentais e Tempo de Avaliação de Laços

### a)
A diferença principal entre `while` e `do-while` está no momento em que a condição é avaliada. No `while`, a condição é testada antes da execução do bloco, portanto o bloco pode executar zero vezes. No `do-while`, o bloco é executado primeiro e a condição é testada depois, garantindo pelo menos uma execução.

### b)
O `for` é mais adequado quando sabemos ou conseguimos controlar claramente a quantidade de repetições, pois reúne inicialização, condição e incremento no cabeçalho. O `while` é adequado quando a repetição depende de uma condição que pode variar durante a execução e não sabemos previamente quantas vezes o laço será executado. O `do-while` é adequado quando o bloco precisa ser executado pelo menos uma vez, como em menus e validação de entrada.

### c)
`while (condicao);` não é erro de compilação. O ponto e vírgula representa um corpo vazio para o `while`. Se `condicao` for verdadeira e nunca for alterada para falsa, o programa ficará preso em um laço infinito, executando apenas o comando vazio.

## Questão 02 – Escopo e Tempo de Vida de Variáveis de Bloco

### a)
A variável `soma` foi declarada dentro do bloco do `for`. Portanto, ela só existe e pode ser acessada dentro desse bloco. Quando o `printf` está fora do `for`, `soma` está fora do seu escopo e não pode ser utilizada.

### b)
Mesmo colocando o `printf` dentro do `for`, a variável `soma` seria inicializada com `0` a cada nova iteração. Assim, ela não acumularia os quadrados de todas as iterações; em cada repetição começaria novamente do zero.

### c)
A variável acumuladora deve ser declarada e inicializada antes do laço:

```c
#include <stdio.h>

int main(void) {
    int i;
    int soma = 0;

    for (i = 1; i < 10; i++) {
        soma += i * i;
    }

    printf("Soma final = %d\n", soma);

    return 0;
}
```

Em C, uma variável declarada dentro de um bloco `{ }` possui escopo de bloco e só pode ser acessada dentro desse bloco. Seu tempo de vida, no caso de uma variável automática local, está associado à execução do bloco em que foi declarada. Por isso, `soma` deve ser declarada fora do `for` para permanecer disponível após o término do laço e acumular os valores durante todas as iterações.

## Questão 03 – Flexibilidade do Laço for

### a)
A sequência impressa é:

```text
36    18    9    4    2    1
```

Depois de imprimir `1`, ocorre `1 /= 2`, que resulta em `0` na divisão inteira, encerrando o laço.

### b)
No Trecho B, não há inicialização nem incremento no cabeçalho do `for`. A condição executa `getch()`, armazena o caractere em `ch` e compara o resultado com `'X'`. Enquanto o caractere digitado não for `X`, o programa imprime `ch + 1`.

Como `ch` representa um código de caractere, `ch + 1` representa o próximo código na tabela de caracteres. Os parênteses são necessários porque primeiro precisamos realizar a atribuição `(ch = getch())` e depois comparar o valor atribuído com `'X'`.

### c)
O laço pode ser interrompido programaticamente utilizando `break` dentro de uma condição, por exemplo:

```c
for (;;) {
    if (condicao_de_parada) {
        break;
    }
}
```

## Questão 04 – break vs. continue

### a)
O comando `break` encerra imediatamente o laço em que está localizado e a execução continua na primeira instrução depois desse laço.

### b)
O comando `continue` interrompe apenas a iteração atual. Em um `for`, depois do `continue`, é executada a expressão de incremento do cabeçalho e, em seguida, a condição é testada novamente.

### c)
Somente o laço mais interno, ou seja, aquele que contém diretamente o `break`, é interrompido. O laço externo continua sua execução.

## Questão 05 – Operador Vírgula

### a)
O laço executa 5 iterações.

### b)
A saída é:

```text
i = 0, j = 10 | soma = 10
i = 1, j = 9 | soma = 10
i = 2, j = 8 | soma = 10
i = 3, j = 7 | soma = 10
i = 4, j = 6 | soma = 10
```

### c)
Uma versão equivalente utilizando `while` é:

```c
int i = 0, j = 10;

while (i < j) {
    printf("i = %d, j = %d | soma = %d\n", i, j, i + j);
    i++;
    j--;
}
```

## Questão 06 – Laço Sem Corpo

### a)
O valor final de `x` será `6`.

### b)
O operador `x++` é pós-fixado. Primeiro o valor atual de `x` é utilizado na comparação e depois `x` é incrementado.

- `x = 0`: compara `0 < 5` → verdadeiro; depois `x = 1`.
- `x = 1`: compara `1 < 5` → verdadeiro; depois `x = 2`.
- `x = 2`: compara `2 < 5` → verdadeiro; depois `x = 3`.
- `x = 3`: compara `3 < 5` → verdadeiro; depois `x = 4`.
- `x = 4`: compara `4 < 5` → verdadeiro; depois `x = 5`.
- `x = 5`: compara `5 < 5` → falso; depois `x = 6`.

Assim, o laço termina com `x = 6`.

### c)
Uma forma explícita, sem corpo vazio, é:

```c
int x = 0;

while (x < 5) {
    x++;
}

x++;

printf("Valor final de x = %d\n", x);
```
