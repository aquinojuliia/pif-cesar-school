#include <stdio.h>

int main(void) {
    int n, i, j;
    int numero = 1;

    printf("Digite o numero de linhas: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Digite um numero inteiro positivo.\n");
        return 0;
    }

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= i; j++) {
            printf("%d", numero);

            if (j < i) {
                printf(" ");
            }

            numero++;
        }
        printf("\n");
    }

    return 0;
}
