# Lista de Exercícios – Capítulo 5: Funções
## Parte I – Questões teóricas e analíticas

### Questão 01 – Anatomia de uma Função e o Papel do Protótipo

**a)** O protótipo é `float celsius(float);`, declarado antes da função `main()`. Ele informa ao compilador que existe uma função chamada `celsius`, que recebe um `float` e retorna um `float`. A chamada ocorre em `c = celsius(f);`, dentro da `main()`, quando a função é executada com o valor de `f`. A definição é o bloco `float celsius(float fahr) { ... }`, que contém as instruções responsáveis por realizar a conversão.

**b)** O protótipo permite que o compilador conheça antecipadamente o nome, o tipo de retorno e os parâmetros da função. Assim, ele pode verificar se a chamada utiliza a quantidade e os tipos de argumentos esperados. Sem o protótipo e com a definição depois da `main()`, o compilador não teria essa declaração prévia, podendo emitir diagnóstico de função não declarada ou não conseguir verificar corretamente a chamada, conforme o padrão e as opções de compilação utilizados.

**c)** O tipo da função é `float`, pois esse é o tipo do valor que ela devolve com `return`. Os parâmetros indicam os dados recebidos pela função; eles não determinam o tipo de retorno. Uma função pode, por exemplo, receber dois inteiros e retornar um `float`.

### Questão 02 – O Comando return e suas Limitações

**a)** Uma função em C devolve um único valor diretamente por meio de `return`. Na expressão `return soma, media;`, a vírgula é o operador vírgula: primeiro `soma` é avaliada e, em seguida, o valor da expressão final (`media`) é retornado. Portanto, a função não devolve os dois resultados; devolve apenas a média.

**b)** O comando `return;` encerra imediatamente a execução de uma função `void`, sem devolver um valor. Ele não é obrigatório no final de uma função `void`: se o fluxo chegar ao fechamento da função, ela termina normalmente.

**c)** Uma possível reescrita é:

```c
int calcularMedia(int a, int b, int c) {
    int soma = a + b + c;
    return soma / 3;
}

int calcularSoma(int a, int b, int c) {
    return a + b + c;
}
```

São usadas duas funções porque cada chamada de função retorna apenas um valor diretamente. Uma função calcula e retorna a média; a outra calcula e retorna a soma.

### Questão 03 – Funções void, Parâmetros e Assinaturas

**a)**
- `void exibe_mensagem(char* msg);`: recebe um parâmetro do tipo ponteiro para `char` (normalmente usado para uma string) e não retorna valor.
- `int obter_codigo(void);`: não recebe parâmetros e retorna um inteiro. O `void` dentro dos parênteses indica ausência de parâmetros.
- `void limpar_tela(void);`: não recebe parâmetros e não retorna valor.

**b)** Uma função com retorno produz um valor que pode ser armazenado ou utilizado em uma expressão, como uma função que calcula uma soma. Um procedimento, representado em C por uma função `void`, executa uma ação sem devolver um valor, como exibir um menu ou uma mensagem.

**c)** Não. `limpar_tela()` tem tipo de retorno `void`, portanto não fornece um valor que possa ser atribuído a `x`. A chamada correta, isoladamente, é `limpar_tela();`.

### Questão 04 – Recursão: Caso Base, Passo Recursivo e Pilha de Execução

**a)** O caso base é `n == 0`, que retorna `1`. O passo recursivo é `n * fatorial(n - 1)`, que chama a função com um valor menor. Sem o caso base, as chamadas continuariam sem atingir uma condição de parada, podendo esgotar a pilha de execução.

**b)** Rastreamento de `fatorial(4)`:

- Empilhamento: `fatorial(4)` aguarda `4 * fatorial(3)`.
- `fatorial(3)` aguarda `3 * fatorial(2)`.
- `fatorial(2)` aguarda `2 * fatorial(1)`.
- `fatorial(1)` aguarda `1 * fatorial(0)`.
- `fatorial(0)` atinge o caso base e retorna `1`.

Desempilhamento:
- `fatorial(1)` retorna `1 * 1 = 1`.
- `fatorial(2)` retorna `2 * 1 = 2`.
- `fatorial(3)` retorna `3 * 2 = 6`.
- `fatorial(4)` retorna `4 * 6 = 24`.

**c)** Cada chamada recursiva cria um novo contexto de execução na pilha, mantendo seus parâmetros, variáveis locais e o ponto para onde deve voltar. Quando o caso base é alcançado, as chamadas começam a terminar em ordem inversa. Sem uma condição de parada, a pilha pode crescer até exceder o espaço disponível, causando falha no programa.

### Questão 05 – Diretiva #define, Constantes e Macros com Argumentos

**a)** `SQR(2+3)` resulta em `25`, pois a macro expande para `((2+3)*(2+3))`. Já `DOBRO(2+3)` resulta em `8`, pois a expansão sem proteção é `2+3*2`, e a multiplicação tem precedência sobre a adição. Os parênteses em `SQR` preservam o argumento como uma expressão única.

**b)** `#define` é uma diretiva de pré-processamento, não uma instrução C comum; por isso não termina com ponto e vírgula. Por convenção, identificadores de macros e constantes são escritos em maiúsculas para diferenciá-los visualmente de variáveis e funções. Isso é uma convenção, não uma obrigação da linguagem.

**c)** `#define PRN (n) printf("%d", n)` está incorreto como macro com argumento porque há um espaço entre `PRN` e `(`. Assim, o pré-processador interpreta `PRN` como uma macro sem argumentos e o restante como texto de substituição. A forma correta é `#define PRN(n) printf("%d", (n))`. Uma macro realiza substituição textual no pré-processamento, enquanto uma função possui parâmetros e tipos verificados pelo compilador e é executada como uma chamada de função.

### Questão 06 – Diretivas #include, #undef e Compilação Condicional

**a)** `#include <stdio.h>` usa a forma com sinais de menor e maior, normalmente destinada a cabeçalhos das bibliotecas padrão ou caminhos de inclusão configurados pelo compilador. `#include "areas.h"` usa aspas, normalmente para um cabeçalho do próprio projeto; o compilador costuma procurar primeiro no diretório do arquivo atual.

**b)** `#undef SOMA` cancela a definição anterior da macro `SOMA`. Depois dessa diretiva, ela deixa de estar definida para o restante do pré-processamento. `#undef` recebe apenas o nome da macro, sem parâmetros; por isso `#undef SOMA(x,y)` está incorreto.

**c)** Se `DEBUG` não tiver sido definido, será selecionado o trecho do `#else`, imprimindo `Modo normal`. Essa decisão é tomada durante o pré-processamento, antes da compilação propriamente dita. As diretivas controlam quais trechos do código-fonte serão mantidos e não são instruções executadas pelo programa; por isso não aparecem como diretivas no executável final.
