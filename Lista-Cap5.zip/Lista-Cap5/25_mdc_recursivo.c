#include <stdio.h>

int mdc(int a, int b);
void simplifica(int num, int den);

int main(void) {
    int a, b, num, den;
    printf("Digite dois inteiros positivos para calcular o MDC: ");
    scanf("%d %d", &a, &b);
    if (a <= 0 || b <= 0) {
        printf("Os valores devem ser positivos.\n");
        return 1;
    }
    printf("MDC = %d\n", mdc(a, b));

    printf("Digite numerador e denominador da fracao: ");
    scanf("%d %d", &num, &den);
    if (num <= 0 || den <= 0) {
        printf("Numerador e denominador devem ser positivos.\n");
        return 1;
    }
    simplifica(num, den);
    return 0;
}

int mdc(int a, int b) {
    if (b == 0) return a;
    return mdc(b, a % b);
}

void simplifica(int num, int den) {
    int divisor = mdc(num, den);
    printf("Fracao simplificada: %d/%d\n", num / divisor, den / divisor);
}
