#include <stdio.h>

/* Compile normalmente: gcc 24_compilacao_condicional_debug.c -o programa
   Compile com depuracao: gcc -DDEBUG 24_compilacao_condicional_debug.c -o programa */

int somaAteN(int n);

int main(void) {
    int n;
    printf("Digite um inteiro positivo: ");
    scanf("%d", &n);
    if (n < 1) {
        printf("Digite um valor maior que zero.\n");
        return 1;
    }
    printf("Soma de 1 ate %d = %d\n", n, somaAteN(n));
    return 0;
}

int somaAteN(int n) {
    int soma = 0;
    for (int i = 1; i <= n; i++) {
        soma += i;
#ifdef DEBUG
        printf("DEBUG: soma parcial apos %d = %d\n", i, soma);
#endif
    }
    /* Sem DEBUG, as mensagens parciais são removidas no pré-processamento.
       Com -DDEBUG, elas são incluídas e aparecem durante a execução. */
    return soma;
}
