# Lista-Cap5 – Funções

Conteúdo:
- `respostas.md`: respostas das questões teóricas 01 a 06.
- Arquivos `.c`: soluções das questões práticas 07 a 28.
- `areas.h`: cabeçalho utilizado pela questão 22.

Para compilar um exercício, entre nesta pasta e execute, por exemplo:
`gcc 07_soma_dois_inteiros.c -o exercicio`

Na questão 22, mantenha `areas.h` na mesma pasta do arquivo `22_biblioteca_areas.c`.
Na questão 24, compile sem depuração normalmente ou use `gcc -DDEBUG 24_compilacao_condicional_debug.c -o programa` para ativar as mensagens de depuração.

Os programas foram organizados com protótipos antes da `main()`, conforme solicitado no enunciado.
