#include <stdio.h>
int main(void) {
    float lab, sem, exame, media;
    printf("Nota do laboratorio: "); scanf("%f", &lab);
    printf("Nota semestral: "); scanf("%f", &sem);
    printf("Nota do exame final: "); scanf("%f", &exame);
    media = (lab * 2 + sem * 3 + exame * 5) / 10.0;
    printf("Media: %.2f\\n", media);
    if (media < 3.0) puts("Reprovado");
    else if (media < 5.0) puts("Em Recuperacao");
    else puts("Aprovado");
    return 0;
}
