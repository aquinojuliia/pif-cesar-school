#include <stdio.h>

long fibonacci(int n);

int main(void) {
    int quantidade;
    printf("Quantidade de termos (1 a 40): ");
    scanf("%d", &quantidade);
    if (quantidade < 1 || quantidade > 40) {
        printf("Informe uma quantidade entre 1 e 40.\n");
        return 1;
    }

    for (int i = 0; i < quantidade; i++) {
        printf("%ld ", fibonacci(i));
    }
    printf("\n");
    return 0;
}

long fibonacci(int n) {
    if (n == 0) return 0;
    if (n == 1) return 1;
    /* A recursao simples recalcula termos varias vezes, ficando lenta para n grande. */
    return fibonacci(n - 1) + fibonacci(n - 2);
}
