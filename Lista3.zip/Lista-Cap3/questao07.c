#include <stdio.h>

int main(void) {
    int i;

    printf("FOR:\n");
    for (i = 0; i <= 100; i++) {
        printf("%d ", i);
    }

    printf("\n\nWHILE:\n");
    i = 0;
    while (i <= 100) {
        printf("%d ", i);
        i++;
    }

    printf("\n\nDO-WHILE:\n");
    i = 0;
    do {
        printf("%d ", i);
        i++;
    } while (i <= 100);

    /*
     * O for e o mais adequado neste caso, pois sabemos o inicio,
     * a condicao de parada e o incremento da contagem.
     */

    return 0;
}
