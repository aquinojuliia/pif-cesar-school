#include <stdio.h>
int main(void) {
    int n;
    printf("Digite um inteiro: "); scanf("%d", &n);
    if (n % 2 == 0) puts("PAR"); else puts("IMPAR");
    if (n > 0) puts("POSITIVO");
    else if (n < 0) puts("NEGATIVO");
    else puts("ZERO");
    return 0;
}
