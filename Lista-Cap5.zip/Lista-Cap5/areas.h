#ifndef AREAS_H
#define AREAS_H

#define PI 3.14159265358979323846
#define A_CIRC(raio) (PI * (raio) * (raio))
#define A_RET(base, alt) ((base) * (alt))
#define A_TRI(base, alt) (((base) * (alt)) / 2.0)

#endif
