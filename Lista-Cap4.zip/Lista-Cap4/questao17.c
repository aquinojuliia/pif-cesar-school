#include <stdio.h>
int main(void) {
    float compra, final, comissao;
    int opcao;
    printf("Valor da compra: "); scanf("%f", &compra);
    if (compra <= 0) { puts("Valor invalido."); return 0; }
    printf("1 - A vista (10%% desconto)\\n2 - Parcelado em 3x\\nOpcao: ");
    scanf("%d", &opcao);
    switch (opcao) {
        case 1:
            final = compra * 0.90; comissao = final * 0.05;
            printf("Valor final: R$ %.2f\\nComissao: R$ %.2f\\n", final, comissao);
            break;
        case 2:
            comissao = compra * 0.05;
            printf("Cada parcela: R$ %.2f\\nComissao: R$ %.2f\\n", compra/3.0, comissao);
            break;
        default: puts("Opcao invalida.");
    }
    return 0;
}
