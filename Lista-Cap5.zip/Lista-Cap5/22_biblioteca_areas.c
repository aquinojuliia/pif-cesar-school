#include <stdio.h>
#include "areas.h"

int main(void) {
    float raio, base, altura;
    printf("Raio do circulo: ");
    scanf("%f", &raio);
    printf("Base e altura do retangulo: ");
    scanf("%f %f", &base, &altura);
    printf("Base e altura do triangulo: ");
    float baseTri, alturaTri;
    scanf("%f %f", &baseTri, &alturaTri);

    if (raio < 0 || base < 0 || altura < 0 || baseTri < 0 || alturaTri < 0) {
        printf("As medidas nao podem ser negativas.\n");
        return 1;
    }

    printf("Area do circulo = %.2f\n", A_CIRC(raio));
    printf("Area do retangulo = %.2f\n", A_RET(base, altura));
    printf("Area do triangulo = %.2f\n", A_TRI(baseTri, alturaTri));
    return 0;
}
