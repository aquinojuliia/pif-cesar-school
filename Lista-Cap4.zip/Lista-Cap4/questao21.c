#include <stdio.h>
int main(void) {
    float salario, p, aumento; int cargo;
    printf("Salario atual: "); scanf("%f", &salario);
    printf("Cargo (1-Tecnico, 2-Gerente, 3-Demais): "); scanf("%d", &cargo);
    if (salario<0) { puts("Salario invalido."); return 0; }
    switch (cargo) {
        case 1: p = salario<=3000 ? 0.15 : 0.10; break;
        case 2: p = salario<=5000 ? 0.10 : 0.05; break;
        case 3: p = 0.08; break;
        default: puts("Cargo invalido."); return 0;
    }
    aumento=salario*p;
    printf("Aumento: R$ %.2f\\nNovo salario: R$ %.2f\\n", aumento, salario+aumento);
    return 0;
}
