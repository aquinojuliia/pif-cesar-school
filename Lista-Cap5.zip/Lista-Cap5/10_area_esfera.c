#include <stdio.h>

#define PI 3.14159265358979323846

float area(float r);

int main(void) {
    float raio;
    printf("Raio da esfera: ");
    scanf("%f", &raio);
    if (raio < 0) {
        printf("O raio nao pode ser negativo.\n");
    } else {
        printf("Area = %.2f\n", area(raio));
    }
    return 0;
}

float area(float r) {
    return (float)(4.0 * PI * r * r);
}
