#include <stdio.h>

int main(void) {
    int A, B, numero, divisor;
    int primo;
    int soma = 0;

    printf("Digite A: ");
    scanf("%d", &A);

    printf("Digite B: ");
    scanf("%d", &B);

    if (A >= B || A <= 0 || B <= 0) {
        printf("Informe dois numeros positivos com A < B.\n");
        return 0;
    }

    printf("Primos no intervalo [%d, %d]:\n", A, B);

    for (numero = A; numero <= B; numero++) {
        if (numero < 2) {
            continue;
        }

        primo = 1;

        for (divisor = 2; divisor < numero; divisor++) {
            if (numero % divisor == 0) {
                primo = 0;
                break;
            }
        }

        if (primo) {
            printf("%d ", numero);
            soma += numero;
        }
    }

    printf("\nSoma dos primos: %d\n", soma);

    return 0;
}
