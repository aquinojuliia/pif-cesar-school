#include <stdio.h>
int main(void) {
    float nota; int faltas;
    printf("Nota final: "); scanf("%f", &nota);
    printf("Faltas: "); scanf("%d", &faltas);
    if (nota < 0 || nota > 10 || faltas < 0) puts("Dados invalidos.");
    else if (nota >= 9.0) puts(faltas <= 20 ? "Conceito A" : "Conceito B");
    else if (nota >= 7.5) puts(faltas <= 20 ? "Conceito B" : "Conceito C");
    else if (nota >= 5.0) puts(faltas <= 20 ? "Conceito C" : "Conceito D");
    else if (nota >= 4.0) puts(faltas <= 20 ? "Conceito D" : "Conceito E");
    else puts("Conceito E");
    return 0;
}
