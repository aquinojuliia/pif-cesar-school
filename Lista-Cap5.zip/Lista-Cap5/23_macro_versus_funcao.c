#include <stdio.h>

/* Macro sem protecao: DOBRO(2+3) expande para 2+3*2 e resulta em 8. */
#define DOBRO(x) x*2
#define DOBRO_CORRETO(x) ((x) * 2)

int dobro(int x);

int main(void) {
    printf("Macro original: %d\n", DOBRO(2 + 3));
    printf("Funcao: %d\n", dobro(2 + 3));
    printf("Macro corrigida: %d\n", DOBRO_CORRETO(2 + 3));
    return 0;
}

int dobro(int x) {
    return x * 2;
}
