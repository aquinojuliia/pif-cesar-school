#include <stdio.h>

void contagem(int n);
void contagemCrescente(int n);

int main(void) {
    int n;
    printf("Digite um numero positivo: ");
    scanf("%d", &n);
    if (n <= 0) {
        printf("O numero deve ser positivo.\n");
        return 1;
    }

    printf("Contagem regressiva:\n");
    contagem(n);
    printf("Contagem crescente:\n");
    contagemCrescente(n);
    return 0;
}

void contagem(int n) {
    if (n <= 0) {
        printf("Fogo!\n");
        return;
    }
    printf("%d\n", n);
    contagem(n - 1);
}

void contagemCrescente(int n) {
    if (n <= 0) return;
    contagemCrescente(n - 1); // A chamada vem antes do printf para imprimir na ordem crescente.
    printf("%d\n", n);
}
