#include <stdio.h>

int main(void) {
    float nota;
    float maior = 0.0, menor = 10.0;
    float soma = 0.0, media;
    int total = 0;

    printf("Digite as notas (digite -1.0 para encerrar):\n");

    while (1) {
        scanf("%f", &nota);

        if (nota == -1.0) {
            break;
        }

        if (nota < 0.0 || nota > 10.0) {
            printf("Nota invalida. Digite uma nota entre 0 e 10.\n");
            continue;
        }

        if (total == 0) {
            maior = nota;
            menor = nota;
        } else {
            if (nota > maior) maior = nota;
            if (nota < menor) menor = nota;
        }

        soma += nota;
        total++;
    }

    printf("Total de alunos avaliados: %d\n", total);

    if (total > 0) {
        media = soma / total;
        printf("Maior nota: %.2f\n", maior);
        printf("Menor nota: %.2f\n", menor);
        printf("Media geral: %.2f\n", media);
    } else {
        printf("Nenhuma nota foi registrada.\n");
    }

    return 0;
}
