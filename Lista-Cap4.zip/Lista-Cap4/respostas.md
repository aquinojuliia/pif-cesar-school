# Lista de Exercícios – Capítulo 4: Comandos de Decisão

## Questão 01 – Expressões condicionais
**a)** Em `if (x = 0)`, `=` atribui zero a `x`. A expressão resulta em zero (falso), então o bloco do `if` não é executado. Para comparar, usa-se `==`.

**b)** Em C, zero é interpretado como falso e qualquer valor diferente de zero como verdadeiro, tanto para inteiros quanto para reais.

**c)** Em `if (x = -5)`, o valor -5 é atribuído a `x`. Como é diferente de zero, a condição é verdadeira e o bloco é executado.

## Questão 02 – Associação do else
**a)** A saída é `Opção B`. `x > 10` é verdadeiro, mas `y > 10` é falso; o `else` pertence ao `if (y > 10)`.

**b)** O `else` é associado ao `if` mais próximo que ainda não tenha um `else`.

**c)**
```c
if (x > 10) {
    if (y > 10) {
        printf("Opção A\\n");
    }
} else {
    printf("Opção B\\n");
}
```

## Questão 03 – Operador ternário
**a)** `(media >= 7.0) ? 'A' : 'R'` armazena `'A'` se a média for pelo menos 7; caso contrário, armazena `'R'`. Para 6.8, `situacao` recebe `'R'`.

**b)**
```c
media = (nota1 + nota2) / 2.0;
if (media >= 7.0) {
    situacao = 'A';
} else {
    situacao = 'R';
}
```

**c)** Não substitui adequadamente qualquer `if-else`: o ternário produz um valor e é mais indicado para escolher entre duas expressões. Para blocos com vários comandos, `if-else` é mais claro.

## Questão 04 – switch-case
**a)** A saída é:
```text
Prata
Ouro
```
A execução começa no `case 2`; sem `break`, continua no `case 3`, imprimindo as duas mensagens.

**b)** `break` encerra o `switch`. Sem ele, pode ocorrer *fall-through*: a execução continua nos casos seguintes.

**c)** A expressão do `switch` deve ter tipo inteiro ou enumerado, como `int`, `char` ou `enum`. `float` e `double` não são permitidos.

## Questão 05 – Curto-circuito
**a)** A saída é `a = 0, b = 5, c = 8`. Como `a != 0` é falso, `&&` não avalia `++b`; o `else` reduz `c` em 2.

**b)** Com `&&`, se o primeiro operando for falso, o segundo não é avaliado. Com `||`, se o primeiro for verdadeiro, o segundo não é avaliado. Isso é avaliação de curto-circuito.

**c)** Em `a == 0 || ++b > 5`, o primeiro operando é verdadeiro; portanto, `++b` não é executado. O bloco do `if` soma 10 a `c`. Valores finais: `b = 5` e `c = 20`.

## Questão 06 – else-if
**a)** Para idade 65, são impressas `Idoso`, `Adulto` e `Jovem`, pois os três `if` independentes são verdadeiros. O `else` está ligado somente ao último `if`.

**b)** `if` independentes são avaliados separadamente e podem executar vários blocos. Em uma cadeia `else-if`, somente o primeiro bloco cuja condição seja verdadeira é executado.

**c)**
```c
if (idade >= 60) {
    printf("Idoso\\n");
} else if (idade >= 18) {
    printf("Adulto\\n");
} else if (idade >= 12) {
    printf("Jovem\\n");
} else {
    printf("Criança\\n");
}
```
