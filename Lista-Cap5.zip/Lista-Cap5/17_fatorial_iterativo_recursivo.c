#include <stdio.h>

long fatorialIterativo(int n);
long fatorialRecursivo(int n);

int main(void) {
    int n;
    printf("Digite um inteiro entre 0 e 20: ");
    scanf("%d", &n);
    if (n < 0 || n > 20) {
        printf("Valor fora do intervalo permitido.\n");
        return 1;
    }

    long a = fatorialIterativo(n);
    long b = fatorialRecursivo(n);
    printf("Iterativo = %ld\nRecursivo = %ld\n", a, b);
    printf("Os resultados %s.\n", (a == b) ? "coincidem" : "nao coincidem");
    return 0;
}

long fatorialIterativo(int n) {
    long resultado = 1;
    for (int i = 2; i <= n; i++) resultado *= i;
    return resultado;
}

long fatorialRecursivo(int n) {
    if (n <= 1) return 1;
    return n * fatorialRecursivo(n - 1);
}
