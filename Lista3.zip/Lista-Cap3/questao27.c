#include <stdio.h>

int main(void) {
    int valor;
    int cedulas[] = {100, 50, 20, 10, 5, 2};
    int quantidade;
    int i;

    printf("Digite o valor do saque: R$ ");
    scanf("%d", &valor);

    if (valor <= 0) {
        printf("Valor invalido.\n");
        return 0;
    }

    for (i = 0; i < 6; i++) {
        quantidade = 0;

        while (valor >= cedulas[i]) {
            valor -= cedulas[i];
            quantidade++;
        }

        if (quantidade > 0) {
            printf("Cedulas de R$ %d: %d\n", cedulas[i], quantidade);
        }
    }

    if (valor != 0) {
        printf("Nao foi possivel decompor completamente o valor com as cedulas disponiveis.\n");
    }

    return 0;
}
