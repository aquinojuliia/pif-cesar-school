#include <stdio.h>
int main(void) {
    int op; double t, r;
    puts("1-Celsius para Fahrenheit");
    puts("2-Celsius para Kelvin");
    puts("3-Fahrenheit para Celsius");
    puts("4-Kelvin para Celsius");
    printf("Opcao: "); scanf("%d", &op);
    printf("Temperatura: "); scanf("%lf", &t);
    switch (op) {
        case 1: r=t*1.8+32; printf("%.2f F\\n", r); break;
        case 2: r=t+273.15; printf("%.2f K\\n", r); break;
        case 3: r=(t-32)/1.8; printf("%.2f C\\n", r); break;
        case 4: r=t-273.15; printf("%.2f C\\n", r); break;
        default: puts("Opcao invalida.");
    }
    return 0;
}
