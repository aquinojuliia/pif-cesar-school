#include <stdio.h>

int main(void) {
    int opcao;
    float salario, resultado;

    do {
        printf("\n===== FOLHA DE PAGAMENTO =====\n");
        printf("1. Reajuste Salarial\n");
        printf("2. Retencao de Imposto de Renda\n");
        printf("3. Encerrar Programa\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("Digite o salario: R$ ");
                scanf("%f", &salario);

                if (salario <= 2000.0) {
                    resultado = salario * 1.15;
                } else {
                    resultado = salario * 1.10;
                }

                printf("Novo salario: R$ %.2f\n", resultado);
                break;

            case 2:
                printf("Digite o salario: R$ ");
                scanf("%f", &salario);

                if (salario <= 3000.0) {
                    resultado = salario * 0.08;
                } else {
                    resultado = salario * 0.15;
                }

                printf("Valor do imposto: R$ %.2f\n", resultado);
                break;

            case 3:
                printf("Programa encerrado.\n");
                break;

            default:
                printf("Opcao invalida! Escolha 1, 2 ou 3.\n");
        }

    } while (opcao != 3);

    return 0;
}
