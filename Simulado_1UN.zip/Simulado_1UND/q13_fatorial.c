#include <stdio.h>

int main(void) {
    int n, i;
    long long int fatorial = 1;

    printf("Digite um numero inteiro nao negativo: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Entrada invalida: o fatorial nao e definido para numeros negativos.\n");
        return 0;
    }

    for (i = 1; i <= n; i++) {
        fatorial *= i;
    }

    printf("%d! = %lld\n", n, fatorial);

    return 0;
}
