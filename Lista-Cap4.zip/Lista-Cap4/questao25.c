#include <stdio.h>
int main(void) {
    int pagar, entregue, troco;
    int notas[] = {100,50,20,10,5,2};
    int i, qtd;
    printf("Valor a pagar: "); scanf("%d", &pagar);
    printf("Valor entregue: "); scanf("%d", &entregue);
    if (pagar<=0 || entregue<=0) { puts("Valores devem ser positivos."); return 0; }
    if (entregue<pagar) { puts("Valor entregue insuficiente."); return 0; }
    troco=entregue-pagar;
    printf("Troco: R$ %d\\n", troco);
    for (i=0;i<6;i++) {
        qtd=troco/notas[i]; troco%=notas[i];
        if (qtd>0) printf("Cedulas de R$ %d: %d\\n", notas[i], qtd);
    }
    if (troco!=0) printf("Nao e possivel representar R$ %d com as cedulas disponiveis.\\n",troco);
    return 0;
}
